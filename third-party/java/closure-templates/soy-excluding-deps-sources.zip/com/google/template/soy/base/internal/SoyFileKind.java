/*
 * Copyright 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.template.soy.base.internal;


/**
 * Enum for the kind of an input Soy file.
 *
 */
public enum SoyFileKind {
  /**
   * Source file.
   *
   * An output will be generated for this file, if appropriate.
   */
  SRC,

  /**
   * A direct dependency.
   *
   * Can be used by sources, and no output will be generated.
   */
  DEP,

  /**
   * An indirect dependency.
   *
   * Exist only to satisfy dependencies of direct dependencies, and cannot be used by sources.
   */
  INDIRECT_DEP;
}

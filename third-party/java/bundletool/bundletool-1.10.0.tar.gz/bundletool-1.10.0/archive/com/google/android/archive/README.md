Source-code for java/com/android/tools/build/bundletool/archive/dex/classes.dex
which is used to build APKs with build-mode ARCHIVE.

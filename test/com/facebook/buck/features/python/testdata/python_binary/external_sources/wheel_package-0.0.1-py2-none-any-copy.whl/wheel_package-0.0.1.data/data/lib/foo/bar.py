def bar():
    print("imported lib.foo.bar")

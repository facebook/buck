def baz():
    print("imported lib.foobar.baz")

def say_hi():
    print('Hello there!')

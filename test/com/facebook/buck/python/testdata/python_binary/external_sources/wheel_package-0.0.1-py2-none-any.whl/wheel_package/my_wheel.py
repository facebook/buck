from __future__ import print_function

def f():
    print("wheel")

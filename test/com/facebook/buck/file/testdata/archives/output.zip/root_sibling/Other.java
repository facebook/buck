class Other { public static void main(String[] args) { return; } }
